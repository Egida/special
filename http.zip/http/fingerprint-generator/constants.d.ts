export declare const STRINGIFIED_PREFIX: "*STRINGIFIED*";
export declare const MISSING_VALUE_DATASET_TOKEN: "*MISSING_VALUE*";
//# sourceMappingURL=constants.d.ts.map